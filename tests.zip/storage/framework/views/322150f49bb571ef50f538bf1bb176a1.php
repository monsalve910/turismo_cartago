<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Mi Dashboard
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl shadow-lg p-8 mb-8 text-white">
            <h3 class="text-2xl font-bold mb-2">¡Bienvenido, <?php echo e(auth()->user()->name); ?>!</h3>
            <p class="text-emerald-100">Explora nuestros tours y vive experiencias únicas en Cartago, Valle del Cauca.</p>
        </div>

        <div class="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-bold text-gray-800">Mis Reservas</h3>
                <a href="<?php echo e(route('tours.index')); ?>" class="text-emerald-600 hover:text-emerald-800 font-medium text-sm">
                    Ver Tours Disponibles →
                </a>
            </div>

            <?php if(isset($misReservas) && $misReservas->count() > 0): ?>
            <div class="grid gap-4">
                <?php $__currentLoopData = $misReservas->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border border-gray-200 rounded-xl p-4 hover:shadow-md transition">
                    <div class="flex justify-between items-start">
                        <div>
                            <h4 class="font-bold text-gray-800"><?php echo e($reserva->tour->nombre ?? 'Tour no disponible'); ?></h4>
                            <p class="text-sm text-gray-500 mt-1">
                                <svg class="w-4 h-4 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                                <?php echo e(\Carbon\Carbon::parse($reserva->fecha_reservacion)->format('d/m/Y')); ?>

                            </p>
                            <?php if($reserva->guia): ?>
                                <p class="text-xs text-amber-600 mt-1 font-medium">Guía: <?php echo e($reserva->guia->name); ?></p>
                            <?php endif; ?>
                        </div>
                        <span class="px-3 py-1 rounded-full text-xs font-semibold
                                    <?php if($reserva->status == 'pendiente'): ?> bg-yellow-100 text-yellow-700
                                    <?php elseif($reserva->status == 'aprobada'): ?> bg-green-100 text-green-700
                                    <?php elseif($reserva->status == 'iniciada'): ?> bg-cyan-100 text-cyan-700
                                    <?php elseif($reserva->status == 'finalizada'): ?> bg-blue-100 text-blue-700
                                    <?php elseif($reserva->status == 'cancelada'): ?> bg-red-100 text-red-700
                                    <?php else: ?> bg-gray-100 text-gray-700
                                    <?php endif; ?>">
                            <?php echo e(ucfirst($reserva->status)); ?>

                        </span>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if($misReservas->count() > 5): ?>
            <div class="mt-4 text-center">
                <a href="<?php echo e(route('reservaciones.misReservas', auth()->id())); ?>" class="text-emerald-600 hover:text-emerald-800 font-medium">
                    Ver todas mis reservas →
                </a>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <div class="text-center py-8">
                <svg class="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p class="text-gray-500">No tienes reservas aún.</p>
                <a href="<?php echo e(route('tours.index')); ?>" class="inline-block mt-4 bg-emerald-600 text-white px-6 py-2 rounded-lg hover:bg-emerald-700 transition font-medium">
                    Explorar Tours
                </a>
            </div>
            <?php endif; ?>
        </div>

        <?php if(isset($availableTours) && $availableTours->count() > 0): ?>
        <div class="bg-white rounded-2xl shadow-lg p-6">
            <h3 class="text-lg font-bold text-gray-800 mb-4">Tours Disponibles</h3>
            <div class="grid md:grid-cols-3 gap-4">
                <?php $__currentLoopData = $availableTours->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border border-gray-200 rounded-xl overflow-hidden hover:shadow-md transition">
                    <?php if($tour->imagen): ?>
                    <img src="<?php echo e(asset('storage/' . $tour->imagen)); ?>" alt="<?php echo e($tour->nombre); ?>" class="w-full h-32 object-cover">
                    <?php else: ?>
                    <div class="w-full h-32 bg-gradient-to-br from-emerald-400 to-teal-500"></div>
                    <?php endif; ?>
                    <div class="p-4">
                        <h4 class="font-bold text-gray-800 mb-2"><?php echo e($tour->nombre); ?></h4>
                        <div class="flex justify-between items-center">
                            <span class="text-emerald-600 font-bold">$<?php echo e(number_format($tour->precio, 0, ',', '.')); ?></span>
                            
                            <?php if($tour->esta_agotado): ?>
                                <a href="<?php echo e(route('tours.show', $tour->id)); ?>" class="text-sm text-gray-400 hover:text-gray-600 font-medium transition duration-200">
                                    Agotado →
                                </a >
                            <?php else: ?>
                                <a href="<?php echo e(route('tours.show', $tour->id)); ?>" class="text-sm text-emerald-600 hover:text-emerald-800 font-medium transition duration-200">
                                    Ver detalles →
                                </a>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\apesi\turismo-cartago\resources\views/dashboard.blade.php ENDPATH**/ ?>